# College-Management-System
College Management System is a internet based Web Portal that aims at providing information to all levels of management system for the College. This system can be used as a information management system for the college.


For a given registrar / staff / student (Technical / Non-technical) the Administrator creates loginid & password, using these registrar/ staff / student (Technical / Non-technical) can access the system to either upload or download some information from
the database.

The front-end will be HTML pages with Java Script for client side validation where as all business logics will be in PHP reside at middle layer. And these layers will interact with third layer of database, which will be MySql database. The web server will
be Apache. To start working on this project environment required is a server having Apache as web server, MySql as database and LAMP(Linux,Apache,MySql and PHP ) as development environment


demo link- https://youtu.be/r2PZwmBCpOw

Download link- https://projectworlds.in/free-projects/php-projects/college-management-system-project-in-php/

HOW TO DEPLOY LOCALLY.

Step 1: In your web browser, go to
http://www.apachefriends.org/en/xampp.html

Step 2: Click on the download link for XAMPP.

Step 3: When prompted for the download, click "Save" and wait for your
download to finish.

Step 4: Once your download is complete, install the program, click on
"Run"

Step 5: Accept the default settings. A command will open and offer an initial installation prompt. Just hit the Enter key, and accept the default settings. To simplify installation, just hit ENTER when prompted on the command line. You can always change settings, by editing the
configuration files later.

Step 6:When your installation is complete, exit the command window by
typing x on the command line.

Step 7:Start the XAMPP Control Panel.

Step 8:Start the Apache and MySQL components. You can also start the
other components, if you plan to use them.

Step 9:Verify the Apache install, by clicking on the Apache administrative link in the Control Panel.

Step 10:Verify the MySQL installation, by clicking on the MySQL administrative link in the XAMPP Control Panel. If the verification steps
are successful, XAMPP should be successfully installed on your PC. Open a browser and enter "localhost" on your address bar. You will be redirected to a page telling you that you've successfully installed xampp on your system.

Step 1: After successful installation of XAMPP, copy the CMS folder from
CD to htdocs folder.
Htdocs can be reached following;
My Computer--> C drive--> Xampp --> htdocs
Step 2: Open Xampp control panel
Step 3: Start apache server and MySql
Step 4: Go to your browser and type localhost/CMS/installDB.php
This creates the database
Step 5: On Xampp control panel click on MySql admin button.
PhpMyAdmin will open in your browser, click on cms db, select sql.
Copy/paste the INsert.sql file to command line and hit go. If sql error
Occurs, then copy one table at a time.
If all Above 5 steps run successfully only then go step 6 else contact
TEAM 3.
Step 6: Go to your browser and type localhost/CMS/index.php

For ADMIN UserName = admin
password= admin






