<?php
mysql_connect("localhost","root", "") or die("No Connection");
mysql_select_db("assignment") or die("No Database connected!");
?>